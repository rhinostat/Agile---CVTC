package wvincent_shapes;

public class Cylinder extends Shape implements Renderer {

	//Fields
	private float radius;
	private float height;
	
	// MessageBox messageBox = new MessageBox();

	
	//Methods
	
	//Overloaded Constructor
	public Cylinder(Dialog messageBox, float radius, float height) {
		super(messageBox);
		this.radius = radius;
		this.height = height;
	}
	
	//Getters and Setters
	public float getRadius() {
		return this.radius;
	}
	
	public void setRadius(float radius) {
		this.radius = radius;
	}
	
	public float getHeight() {
		return this.height;
	}
	
	public void setHeight(float height) {
		this.height = height;
	}

	
	@Override
	public float getSurfaceArea() {
		return (float) ((2*Math.PI*radius*height) + (2*Math.PI*Math.pow(radius, 2)));
	}

	@Override
	public float getVolume() {
		return (float) (Math.PI*(Math.pow(radius, 2)*height));
	}

	@Override
	public void render() {
		
		this.getMessageBox().show("The height of the Cylinder is: " + this.getHeight() + "\nThe radius of the Cylinder is: " + this.getRadius() + "\nThe Surface Area is: " + getSurfaceArea() + "\nThe Volume is: " + getVolume(), "Cylinder");
	}


}
