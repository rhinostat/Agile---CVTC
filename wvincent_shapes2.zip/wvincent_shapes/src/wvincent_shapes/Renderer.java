package wvincent_shapes;

public interface Renderer {

	public void render();
}
