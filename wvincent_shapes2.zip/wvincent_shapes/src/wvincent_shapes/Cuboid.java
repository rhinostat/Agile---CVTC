package wvincent_shapes;


public class Cuboid extends Shape implements Renderer {

	//Fields
	private float width = 0.0f;
	private float height = 0.0f;
	private float depth = 0.0f;
	
	// MessageBox messageBox = new MessageBox();
	
	//Methods
	
	public Cuboid(Dialog messageBox, float width, float height, float depth) {
		super(messageBox);
		this.width = width;
		this.height = height;
		this.depth = depth;
	}
	
	//Getters and Setters
	public float getWidth() {
		return this.width;
	}
	
	public void setWidth(float width) {
		this.width = width;
	}
	
	public float getHeight() {
		return this.height;
	}
	
	public void setHeight(float height) {
		this.height = height;
	}
	
	public float getDepth() {
		return this.depth;
	}
	
	public void setDepth(float depth) {
		this.depth = depth;
	}
	
	
	@Override
	public float getSurfaceArea() {
		return height*width*6;
	}

	@Override
	public float getVolume() {
		return height*width*depth;
	}

	@Override
	public void render() {
		
		this.getMessageBox().show("The width of the cuboid is: " + this.getWidth() + "\nThe height of the cuboid is: "
				+ this.getHeight() + "\nThe Depth of the cuboid is: " + this.getDepth() + "\nThe Surface Area is: " + getSurfaceArea() + "\nThe Volume is: " + getVolume(), "Cuboid");
	}
	
}
