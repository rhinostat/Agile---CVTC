package wvincent_shapes;


public class Sphere extends Shape implements Renderer {

	

	//Fields
	private float radius;
	
	// MessageBox messageBox = new MessageBox();

	
	//Overloaded Constructor
	public Sphere(Dialog messageBox, float radius) {
		super(messageBox);
		this.radius = radius;
	}
	
	//Getters and Setters
	public float getRadius() {
		return this.radius;
	}
	
	public void setRadius(float radius) {
		this.radius = radius;
	}
	
	
	@Override
	public float getSurfaceArea() {
		return (float) (4*Math.PI*Math.pow(radius, 2));
	}

	@Override
	public float getVolume() {
		return (float) ((4/3)*Math.PI*Math.pow(radius, 3));
	}

	@Override
	public void render() {
		this.getMessageBox().show("The radius of the sphere is: " + this.getRadius() + "\nThe Surface Area is: " + getSurfaceArea() + "\nThe Volume is: " + getVolume(), "Sphere");
	}


}
