package wvincent_shapes;

public class ShapesTest {

	public static void main(String[] args) {

		
		Renderer cube1 = new Cuboid(new MessageBox(), 10, 10, 10);
		Renderer cylinder1 = new Cylinder(new MessageBox(), 10, 10);
		Renderer sphere1 = new Sphere(new MessageBox(), 10);
		
		cube1.render();
		cylinder1.render();
		sphere1.render();
		
		
	}

}
