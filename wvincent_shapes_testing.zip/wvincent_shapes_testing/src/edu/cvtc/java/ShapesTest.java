package edu.cvtc.java;

public class ShapesTest {

	public static void main(String[] args) {

		
//		Cuboid cube1 = new Cuboid(10, 10, 10);
//		Cylinder cylinder1 = new Cylinder(10, 10);
//		Sphere sphere1 = new Sphere(10);
		
//		cube1.render();
//		cylinder1.render();
//		sphere1.render();
		
		
	}

}
