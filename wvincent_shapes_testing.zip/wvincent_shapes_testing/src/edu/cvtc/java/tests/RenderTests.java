package edu.cvtc.java.tests;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.cvtc.java.Cuboid;
import edu.cvtc.java.Cylinder;
import edu.cvtc.java.MessageBoxSub;
import edu.cvtc.java.Sphere;

public class RenderTests {

	@Test
	public void test() {

	MessageBoxSub box1 = new MessageBoxSub();
	
	Cuboid cube1 = new Cuboid(box1, 10.0, 10.0, 10.0);
	Cylinder cylinder1 = new Cylinder(box1, 10.0, 10.0);
	Sphere sphere1 = new Sphere(box1, 10.0);
	
	cube1.render();
	cylinder1.render();
	sphere1.render();
	
	}

}
