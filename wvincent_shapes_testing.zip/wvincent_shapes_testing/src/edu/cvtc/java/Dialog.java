package edu.cvtc.java;

public interface Dialog {
	
	public int show(String message, String title);

}
