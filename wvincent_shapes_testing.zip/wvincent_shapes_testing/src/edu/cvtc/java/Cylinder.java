package edu.cvtc.java;

public class Cylinder extends Shape implements Renderer {

	//Fields
	private Float radius;
	private Float height;

	
	//Methods
	
	//Overloaded Constructor
	public Cylinder(Dialog messageBox, double radius, double height) {
		super(messageBox);
		this.radius = (float) radius;
		this.height = (float) height;
		super.getMessageBox();
	}
	
	//Getters and Setters
	public Float getRadius() {
		return this.radius;
	}
	
	public void setRadius(Float radius) {
		this.radius = radius;
	}
	
	public Float getHeight() {
		return this.height;
	}
	
	public void setHeight(Float height) {
		this.height = height;
	}

	
	@Override
	public float getSurfaceArea() {
		return (float) ((2*Math.PI*radius*height) + (2*Math.PI*Math.pow(radius, 2)));
	}

	@Override
	public float getVolume() {
		return (float) (Math.PI*(Math.pow(radius, 2)*height));
	}

	@Override
	public void render() {
		
		super.getMessageBox().show("The height of the Cylinder is: " + this.getHeight() + "\nThe radius of the Cylinder is: " + this.getRadius(), "Cylinder");
	}


}
