package wvincent_shapes;

public interface Dialog {
	
	public int show(String message, String title);

}
