package wvincent_shapes;



public class ShapesTest {

	public static void main(String[] args) {
		
		ShapesFactory shapeFactory = new ShapesFactory();

		Shape shape1 = shapeFactory.getShape("Cuboid");
		shape1.render();
		Shape shape2 = shapeFactory.getShape("Cylinder");
		shape2.render();
		Shape shape3 = shapeFactory.getShape("Sphere");
		shape3.render();

		
		//Renderer cube1 = new Cuboid(new MessageBox(), 10, 10, 10);
		//Renderer cylinder1 = new Cylinder(new MessageBox(), 10, 10);
		//Renderer sphere1 = new Sphere(new MessageBox(), 10);
		
		//cube1.render();
		//cylinder1.render();
		//sphere1.render();
		
		
	}

}
