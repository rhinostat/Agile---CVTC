package wvincent_shapes;

public abstract class Shape implements Renderer {

	//Fields
	private Dialog messageBox;
	
	//Methods
	abstract float getSurfaceArea();
	abstract float getVolume();
	
	//Getters Setters
	protected Dialog getMessageBox() {
		return this.messageBox;
	}
	
	public void setMessageBox(Dialog messageBox) {
		this.messageBox = messageBox;
	}
	
	public Shape(Dialog messageBox) {
		super();
		this.messageBox = messageBox;
		
	}
}
