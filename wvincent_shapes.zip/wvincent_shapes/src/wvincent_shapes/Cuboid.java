package wvincent_shapes;


import javax.swing.JFrame;
import javax.swing.JOptionPane;


/**
 * @author WJ Vincent II
 *
 */
public class Cuboid extends Shape 
{
	// Variable declaration
	private float width = 0;
	private float height = 0;
	private float depth = 0;
	
	
	// Getters and Setters
	public float getWidth()
	{
		return width;
	}
	
	public void setWidth(float width)
	{
		this.width = width;		
		
	}
	
	public float getHeight()
	{
		return height;
	}
	
	public void setHeight(float height)
	{
		this.height = height;	
	
	}
	
	public float getDepth()
	{
		return depth;
	}
	
	public void setDepth(float depth)
	{
		this.depth = depth;	
		
	}
	
	 // Constructor for cuboid object
	public Cuboid(float width, float height, float depth) 
	{
		setWidth(width);
		
		setHeight(height);
		
		setDepth(depth);
	}

	
	// Surface Area calculation method. Inherited from abstract in Shape.java
	@Override
	public float surfaceArea() 
	{
		float surfaceArea = (width * height) * 6;
		
		return surfaceArea;
	}

	// Volume calculation method. Inherited from abstract in Shape.java
	@Override
	public float volume() 
	{
		float volume = width * height * depth;
		
		return volume;
	}


	// Render method for message boxes. Inherited from abstract in Shape.java
	@Override
	public void render() 
	{
		
		JFrame frame = new JFrame("Show Message Dialog");
		
		JOptionPane.showMessageDialog(frame, "The surface area of the cube is " + this.surfaceArea() + "\n" +
											 "The volume of the cube is " + this.volume());
		
	}

}