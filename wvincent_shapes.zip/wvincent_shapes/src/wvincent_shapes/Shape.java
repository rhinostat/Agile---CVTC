package wvincent_shapes;

public abstract class Shape {
	
	// Abstract methods for surface area/volume calculation and message boxes
	public abstract float surfaceArea();
	
	public abstract float volume();
	
	public abstract void render();

}
