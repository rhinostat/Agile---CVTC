package wvincent_shapes;

import java.util.Scanner;

import javax.swing.JOptionPane;

/**
 * @author WJ Vincent II
 *
 */
public class ShapesTest {


	public static void main(String[] args) 
	{
		// Creating cube variables for user input
		float userCubeWidth;
		float userCubeHeight;
		float userCubeDepth;
		
		// Creating cylinder variables for user input
		float userCylinderRadius;
		float userCylinderHeight;
		
		// Creating sphere variable for user input
		float userSphereRadius;
		
		
		// Instantiating Shape objects
		Cuboid cuboidTest = new Cuboid(0, 0, 0);
		Cylinder cylinderTest = new Cylinder (0, 0);
		Sphere sphereTest = new Sphere (0);
		
		
		// Instantiating new Scanner object
		Scanner userInput = new Scanner(System.in);
		
		
		// Prompting for user input for cube width
		System.out.print("Enter the width of the cube: ");
		userCubeWidth = userInput.nextFloat();
		
		// Prompting for user input for cube height
		System.out.print("Enter the height of the cube: ");
		userCubeHeight = userInput.nextFloat();
		
		// Prompting for user input for cube depth
		System.out.print("Enter the depth of the cube: ");
		userCubeDepth = userInput.nextFloat();
		
		// Prompting for user input for cylinder radius
		System.out.print("Enter the radius of the cylinder: ");
		userCylinderRadius = userInput.nextFloat();
		
		// Prompting for user input for cylinder height
		System.out.print("Enter the height of the cylinder: ");
		userCylinderHeight = userInput.nextFloat();
		
		// Prompting for user input for sphere radius
		System.out.print("Enter the radius of the sphere: ");
		userSphereRadius = userInput.nextFloat();
		
		// Closing resource for userInput
		userInput.close();
		
		// Validation for non positive numbers for user cube input
		if(userCubeWidth <= 0 || userCubeHeight <= 0 || userCubeDepth <= 0 ) {
			
			JOptionPane.showMessageDialog(null,"Your Cube Inputs must all be positive numbers. Try Again.");
			
		} else { 
			cuboidTest.setWidth(userCubeWidth);
			cuboidTest.setHeight(userCubeHeight);
			cuboidTest.setDepth(userCubeDepth);
			
			// Printing cube results of user input
			cuboidTest.render();
		}
		
		// Validation for non positive numbers for user cylinder input
		if(userCylinderRadius <= 0 || userCylinderHeight <= 0) {
			
			JOptionPane.showMessageDialog(null,"Your Cylinder Inputs must all be positive numbers. Try Again.");
			
		} else {
			
			cylinderTest.setRadius(userCylinderRadius);
			cylinderTest.setHeight(userCylinderHeight);
			
			// Printing cylinder results of user input
			 cylinderTest.render();
			
		}
		
		// Validation for non positive numbers for user sphere input
		if(userSphereRadius <= 0) {
			
			JOptionPane.showMessageDialog(null,"Your Sphere Radius must be a positive number.  Try Again.");
			
			
			
		} else {
			
			sphereTest.setRadius(userSphereRadius);
			
			// Printing sphere results of user input
			 sphereTest.render();
			
		}	
		
		
	}

}