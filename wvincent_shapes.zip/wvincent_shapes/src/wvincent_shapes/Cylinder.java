package wvincent_shapes;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


/**
 * @author WJ Vincent II
 *
 */
public class Cylinder extends Shape {

	// Variable declaration
	private float radius = 0;
	private float height = 0;
	
	// Getters and Setters
	public float getRadius()
	{
		return radius;
	}
	
	public void setRadius(float radius)
	{
		this.radius = radius;
		
	}
	
	public float getHeight()
	{
		return height;
	}
	
	public void setHeight(float height)
	{
		this.height = height;
		
	}
	
	 // Constructor for cylinder object	
	public Cylinder(float radius, float height) 
	{
		setRadius(radius);
		
		setHeight(height);
	}

	 // Surface Area calculation method. Inherited from abstract in Shape.java
	@Override
	public float surfaceArea() 
	{
		float surfaceArea = (float) ((2 * Math.PI * radius * height) + (2 * Math.PI * Math.pow(radius, 2)));
		
		return surfaceArea;
	}

	// Volume calculation method. Inherited from abstract in Shape.java
	@Override
	public float volume() 
	{
		float volume = (float) (Math.PI * Math.pow(radius, 2) * height);
		
		return volume;
	}

	// Render method for message boxes. Inherited from abstract in Shape.java
	@Override
	 public void render() 
	{
		JFrame frame = new JFrame("Show Message Dialog");
		
		JOptionPane.showMessageDialog(frame, "The surface area of the cylinder is " + this.surfaceArea() + "\n" +
											 "The volume of the cylinder is " + this.volume());

	}

}