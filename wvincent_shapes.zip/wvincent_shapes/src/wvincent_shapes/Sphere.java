package wvincent_shapes;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


/**
 * @author WJ Vincent II
 *
 */
public class Sphere extends Shape 
{
    // Variable Declaration
	private float radius = 0;
	
	// Getters and Setters
	public float getRadius()
	{
		return radius;
	}
	
	public void setRadius(float radius)
	{
		this.radius = radius;

	}
	
	 // Constructor for sphere object
	public Sphere(float radius) 
	{
		setRadius(radius);
	}

	 // Surface Area calculation method. Inherited from abstract in Shape.java
	@Override
	public float surfaceArea() 
	{
		float surfaceArea = (float) (4 * Math.PI * Math.pow(radius, 2));
		
		return surfaceArea;
	}

	// Volume calculation method. Inherited from abstract in Shape.java
	@Override
	public float volume() 
	{
		float volume = (float) (4 * Math.PI * (Math.pow(radius, 3) / 3));
		
		return volume;
	}

	// Render method for message boxes. Inherited from abstract in Shape.java
	@Override
	public void render() 
	{
		JFrame frame = new JFrame("Show Message Dialog");
		
		JOptionPane.showMessageDialog(frame, "The surface area of the sphere is " + this.surfaceArea() + "\n" +
											 "The volume of the sphere is " + this.volume());

	}

}
