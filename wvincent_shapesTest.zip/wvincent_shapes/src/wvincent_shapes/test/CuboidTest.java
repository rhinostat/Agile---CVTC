package wvincent_shapes.test;

import static org.junit.Assert.*;

import org.junit.Test;

import wvincent_shapes.Cuboid;
import wvincent_shapes.Shape;

public class CuboidTest {
	
	Cuboid cube1 = new Cuboid(1, 1, 1);
	Shape cube2;

	@Test
	public void testConstructor() {
		cube2 = new Cuboid(1, 1, 1);
		
		assertTrue(cube1 instanceof Cuboid);
	}
	
	@Test 
	public void testGetWidth() {
		// cube1 = new Cuboid(1,1,1);
		assertEquals(1.0, cube1.getWidth(), 0.0);
		
		
	}
	
	@Test 
	public void testGetHeight() {
		// cube1 = new Cuboid(1,1,1);
		assertEquals(1.0, cube1.getHeight(), 0.0);
		
		
	}
	
	@Test 
	public void testGetDepth() {
		// cube1 = new Cuboid(1,1,1);
		assertEquals(1.0, cube1.getDepth(), 0.0);
		
		
	}
	
	@Test 
	public void testGetSurfaceArea() {
		// cube1 = new Cuboid(1,1,1);
		assertEquals(1.0, cube1.getWidth(), 0.0);
		assertEquals(1.0, cube1.getHeight(), 0.0);
		assertEquals(6.0, cube1.surfaceArea(), 0.0);
		
		
		
	}
	
	@Test 
	public void testGetVolume() {
		// cube1 = new Cuboid(1,1,1);
		assertEquals(1.0, cube1.getWidth(), 0.0);
		assertEquals(1.0, cube1.getHeight(), 0.0);
		assertEquals(1.0, cube1.getDepth(), 0.0);
		assertEquals(cube1.getWidth(), cube1.getHeight(), cube1.getDepth());
		
		
		
	}

}
